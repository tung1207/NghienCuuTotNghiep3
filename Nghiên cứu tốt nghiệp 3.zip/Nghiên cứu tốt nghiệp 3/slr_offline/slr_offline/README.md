# Sign Language Recognition Project </l>
## 1. Giới thiệu:  
Bài toán :  
Nhận diện ngôn ngữ ký hiệu (thủ ngữ).  
Đề tài thực hiện ở mức cơ bản, nhận diện đánh vần chữ cái bằng tay , xử lý ảnh tĩnh với 24 lớp.

## 2. Cấu trúc thư mục:  
* preprocessing.py:  
Thư viện các hàm tiền xử lý  
* train.py:  
Chương trình train CNN Model  
* slr_models:  
Thư mục chưa các model đã train, sử dụng cho realtime_slr  
## 3. Hướng dẫn cài đặt: 

### 3.1 Cài đặt môi trường:   
    Tạo môi trường ảo mới, gợi ý sử dụng anaconda:  
    conda create -n ai_proj python
    conda activet ai_proj  

    Cài đặt các thư viện cần thiết:  
    pip install -r requirements.txt  

## 3.2 Tài dữ liệu :  
    Dữ liệu hiện tại được lấy từ Dataset Sign Language MNIST trên kaggle 
    [link](https://www.kaggle.com/datamunge/sign-language-mnist)
    Tải về, giải nén, đặt vào thư mục inp/ trong folder chứa code 

## 3.3 Tự train model: 
    Chỉnh sửa các thông số trong train.py cho phù hợp, sau đó thực hiện chạy:  
    python train.py  
